import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import BackEnd.Text;
import BackEnd.Word;

import java.util.ArrayList;

public class BackEndTest {

	private Word w;
	private Text t;

	private ArrayList<Word> words;

	@Before
	public void setUp() {
		w = new Word("Marto");
		t = new Text();
		words = new ArrayList<Word>();
		t.add(w, words);
	}

	@Test
	public void testAdd() {
		assertEquals(t.getNumberOfLetters(), w.getWord().length());
	}

	@Test
	public void testRemove() {
		t.remove(w, words);
		assertEquals(t.getNumberOfLetters(), 0);
	}

	@Test
	public void testClear() {
		t.clear(words);
		assertEquals(t.getNumberOfLetters(), 0);
	}

	@Test
	public void testGetNumberOfLetters() {
		assertEquals(t.getNumberOfLetters(), w.getWord().length());
	}

	@Test
	public void testCheck() {
		assertEquals(t.check(w, "Marto"), true);
	}

}
