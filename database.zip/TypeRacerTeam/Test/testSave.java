import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import BackEnd.Save;

public class testSave {

	private Save s;
	ArrayList<Save> savedInfo;

	@Before
	public void setUp() throws IOException {
		savedInfo = new ArrayList<Save>();
		s = new Save();
		Save s1 = new Save("Hristo", 44);
		Save s2 = new Save("Georgi", 32);
		Save s3 = new Save("Test", 37);
		Save s4 = new Save("Pesho", 22);
		s.loadFileOpenIt();
		s.setInFile(s1);
		s.setInFile(s2);
		s.setInFile(s3);
		s.setInFile(s4);
		s.stopWrite();
		savedInfo = s.getFromFile();
	}

	@Test
	public void testSetInFile() {

	}

	@Test
	public void testGetFromFile() {

	}

	@Test
	public void testLoadFileOpenIt() throws IOException {
		assertEquals(s.loadFileOpenIt(), true);
	}

}
