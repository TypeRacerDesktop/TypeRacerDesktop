import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import BackEnd.Chronometer;

public class testChronometer {

	private Chronometer ch;

	@Before
	public void setUp() throws IOException {
		ch = new Chronometer();
	}

	@Test
	public void testGetTimeNow() {

	}

	@Test
	public void testGetTimeTillNow() {

	}

}
