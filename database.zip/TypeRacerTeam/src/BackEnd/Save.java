package BackEnd;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// trqbva trqbva da se obmisli grafika

public class Save {
	private String username;
	private int score;
	private BufferedWriter bw;

	public Save(String username, int score) {
		this.username = username;
		this.score = score;
	}

	public Save() {
		
	}
	
	public boolean loadFileOpenIt() throws IOException {
		File file = new File("D:\\eclipse\\TypeRacerDoc\\savedInfo.txt");

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
		this.bw = new BufferedWriter(fw);
		return true;
	}

	public String getUsername() {
		return username;
	}
	
	public int getScore() {
		return score;
	}

	public void setInFile(Save user) throws IOException {
		bw.write(user.getUsername() + " " + user.getScore());
		bw.newLine();
	}

	public void stopWrite() throws IOException {
		bw.close();
	}

	public ArrayList<Save> getFromFile() throws IOException {
		ArrayList<Save> savedInfo = new ArrayList<Save>();
		String line = null;

		@SuppressWarnings("resource")
		BufferedReader buffRdr = new BufferedReader(new FileReader(
				"D:\\eclipse\\TypeRacerDoc\\savedInfo.txt"));
		line = buffRdr.readLine();
		while (line != null) {
			String content[] = line.split(" ");
			Save s = new Save(content[0], Integer.parseInt(content[1]));
			savedInfo.add(s);
			line = buffRdr.readLine();
		}
		return savedInfo;
	}

	public ArrayList<Save> getTheScourFromBestToWorst(ArrayList<Save> userData) {
		ArrayList<Save> scoreRating = new ArrayList<Save>();

		for (Save s : userData) {
			scoreRating.add(s);
		}

		Collections.sort(scoreRating, new Comparator<Save>() {
			public int compare(Save s1, Save s2) {
				return s2.getScore() - s1.getScore();
			}
		});

		return scoreRating;
	}

}
