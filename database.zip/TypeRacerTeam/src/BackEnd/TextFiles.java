package BackEnd;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TextFiles {
	private String name;
	private String content;

	public TextFiles(String name) {
		this.name = "D:\\eclipse\\TypeRacerDoc\\" + name;
		this.content = "";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String loadTheText() throws IOException {
		String line = null;

		@SuppressWarnings("resource")
		BufferedReader buffRdr = new BufferedReader(new FileReader(this.name));
		line = buffRdr.readLine();
		while (line != null) {
			this.content += line;
			line = buffRdr.readLine();
		}
		return this.content;
	}

	public void fromTextFileToWord(ArrayList<Word> words) {
		String helpForSplit[] = this.content.split(" ");
		Text t = new Text();
		for (String s : helpForSplit) {
			Word w = new Word(s);
			t.add(w, words);
		}
		System.out.println(t.getNumberOfLetters());
	}
}
