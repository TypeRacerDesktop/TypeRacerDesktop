package BackEnd;

// 1 secunda = 1000 milisecundi 
// trqbva da pochna da pravq proverka ili pak da nakarame programata da raboti za 60 sec.

public class Chronometer {
	private long startTime;
	private long endTime;

	public String getTimeNow() {
		long result = endTime - startTime;
		String toStr = "";

		if ((result > 1000)) {
			toStr = Long.toString(result / 1000) + ","
					+ Long.toString(result - ((result / 1000) * 1000));
		}
		return toStr;
	}

	public long startTime() {
		startTime = System.currentTimeMillis();
		return startTime;
	}

	public void endTime() {
		endTime = System.currentTimeMillis();
	}

	public String getTillNow(long theBeginTime) {
		long timeNow = System.currentTimeMillis();
		long untilnow = timeNow - theBeginTime;
		String toStr = "";

		if ((untilnow > 1000)) {
			toStr = Long.toString(untilnow / 1000) + ","
					+ Long.toString(untilnow - ((untilnow / 1000) * 1000));
		}
		return toStr;
	}
}
