package BackEnd;

import java.util.ArrayList;

public class Text {

	private int lettersSum;
	private int wordSum;

	public Text() {
		lettersSum = 0;
		wordSum = 0;
	}

	public void add(Word w, ArrayList<Word> words) {
		words.add(w);
		lettersSum += w.getWord().length();
		wordSum += wordSum;
	}

	public void remove(Word w, ArrayList<Word> words) {
		words.remove(w);
		lettersSum -= w.getWord().length();
		wordSum -= wordSum;
	}

	public void clear(ArrayList<Word> words) {
		words.clear();
		lettersSum = 0;
		wordSum = 0;
	}

	public int getNumberOfLetters() {
		return lettersSum;
	}
	
	public int getNumberOfWords() {
		return wordSum;
	}

	public boolean check(Word w, String s) {
		return (w.getWord().equals(s));
	}	

}
