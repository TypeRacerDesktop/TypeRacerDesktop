package BackEnd;

import java.io.IOException;
import java.util.ArrayList;

// kapsulaciq / izchistvane na koda

// You can calculate your wpm by timing yourself for a minute while you type. 
// Once you have finished count your characters, counting spaces as well. 
// Divide the number by five and that number is your wpm. 
// There are also free online typing tests that will give you your wpm. 
// Remember that five characters in a minute is equal to one wpm.

public class MainGame {

	public static void main(String[] args) throws IOException,
			InterruptedException {
		ArrayList<Save> savedInfo = new ArrayList<Save>();

		Save s = new Save();
		Save s1 = new Save("Hristo", 44);
		Save s2 = new Save("Georgi", 32);
		Save s3 = new Save("Test", 37);
		Save s4 = new Save("Pesho", 22);
		s.loadFileOpenIt();
		s.setInFile(s1);
		s.setInFile(s2);
		s.setInFile(s3);
		s.setInFile(s4);
		s.stopWrite();
		savedInfo = s.getFromFile();

		for (Save save : savedInfo) {
			System.out.println(save.getUsername() + " " + save.getScore());
		}

		System.out.println("######################");

		savedInfo = s.getTheScourFromBestToWorst(savedInfo);
		for (Save save : savedInfo) {
			System.out.println(save.getUsername() + " " + save.getScore());
		}

		Chronometer ch = new Chronometer();
		long t = ch.startTime();
		Thread.sleep(2034);
		System.out.println("That took " + ch.getTillNow(t) + " seconds");
		Thread.sleep(2034);
		ch.endTime();
		System.out.println("That took " + ch.getTimeNow() + " seconds");

	}

}
