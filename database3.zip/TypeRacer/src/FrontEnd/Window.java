package FrontEnd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.WeakHashMap;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

import BackEnd.Chronometer;
import BackEnd.DataFiles;

//moje da se napravi nov
// class koito da ti
// otvarq tam menuto sas
// slojnostite i ot tam
// da ti vrashta imeto
// na faila koito trqbva
// da otvorish i veche
// da se zarejda nov
// class koito realno da
// ti pravi tam
// hronometar i celiq
// nov prozorec. Sled
// koeto shte ima da se
// otvarq nov class
// koito shte e lastest
// ranking results ili
// neshto takova.

public class Window {
	public Display d;
	public Shell shell;
	public Rectangle bds;
	private int width;
	private int height;
	private int speed;
	private int letterCounter;
	private ArrayList<String> words = new ArrayList<String>();

	public Window() {
		d = new Display();
		shell = new Shell(d);

		bds = shell.getDisplay().getBounds();
		width = bds.width;
		height = bds.height;
		speed = 0;
		letterCounter = 0;
	}

	public void createCanvas() {

		shell.setMaximized(true);
		shell.setText("Desktop TypeRacer");

		final Button startGame = new Button(shell, SWT.PUSH);
		startGame.setText("Start Game");
		startGame
				.setBounds((width / 2) - 50, (height / 2) - 50 - 200, 100, 100);
		startGame.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				startGame();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button rankList = new Button(shell, SWT.PUSH);
		rankList.setText("Rank List");
		rankList.setBounds((width / 2) - 50, (height / 2) - 50 - 100, 100, 100);
		rankList.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				rankList();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button about = new Button(shell, SWT.PUSH);
		about.setText("About");
		about.setBounds((width / 2) - 50, (height / 2) - 50, 100, 100);
		about.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				about();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		shell.open();

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				d.sleep();
			}
		}
	}

	public void clearScreen() {
		for (Control kid : shell.getChildren()) {
			kid.dispose();
		}
		// for (Widget kid : shell.) {
		// kid.dispose();
		//
		// }
	}

	public int wpmCounter(int numberOfLetters, long timeSinceNow) {
		int wordsCount = (int) (numberOfLetters / 5);
		float minute = (float) timeSinceNow / 60;
		int newWPM = (int) (wordsCount / minute);

		return newWPM;
	}

	public void startGame() {
		final Button easy = new Button(shell, SWT.PUSH);
		easy.setText("150");
		easy.setBounds((width / 2) - 50, (height / 2) - 50 - 200, 100, 100);
		easy.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				try {
					levelSelected(1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button medium = new Button(shell, SWT.PUSH);
		medium.setText("250");
		medium.setBounds((width / 2) - 50, (height / 2) - 50 - 100, 100, 100);
		medium.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				try {
					levelSelected(2);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button hard = new Button(shell, SWT.PUSH);
		hard.setText("350");
		hard.setBounds((width / 2) - 50, (height / 2) - 50, 100, 100);
		hard.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen();
				try {
					levelSelected(3);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		shell.open();

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				d.sleep();
			}
		}
		d.dispose();
	}

	public void drawTheText(String con) {
		con = con.substring(1, con.length());
		String[] text = con.split(" ");
		String correct = null;
		boolean firstTime = false;
		int letterCount = 0;
		for (String s : text) {
			correct += s + " ";
			letterCount += s.length() + 1;
			if (letterCount > 190) {
				letterCount = 0;
				if (firstTime != true)	{
					words.add(correct.substring(7, correct.length()));
					firstTime = true;
				} else {
					words.add(correct.substring(4, correct.length()));		
				}
				correct = null;
			}
		}
		if (letterCount != 0) {
			words.add(correct.substring(4, correct.length()));
		}
	}

	public void rankList() {

	}

	public void about() {
		GC gc = new GC(shell);
		Font font = new Font(d, "Arial", 60, SWT.NORMAL);
		gc.setFont(font);

		gc.drawText("Tova e na Iceto i Gosheto", 200, 100);
	}

	public void levelSelected(int i) throws IOException {
		Random rand = new Random();
		Font font;
		DataFiles df = null;
		GC gc = new GC(shell);
		String con;
		final Chronometer ch = new Chronometer();
		int widthHelper = (((width / 20) + (width - (width / 4)) + 50) - ((width / 20)
				+ width - (width / 4))) / 2;
		int chWidthHelper = (((width / 20) + width - (width / 4)) + widthHelper)
				+ ((width - (((width / 20) + width - (width / 4)) + widthHelper)) / 2);
		int chHeightHelper = height / 20;
		int wpmHeightHelper = height / 6;
		int num = rand.nextInt(10);
		ch.startTime();
		switch (i) {
		case 1:
			df = new DataFiles("Book10.txt"); // + num
			break;
		case 2:
			df = new DataFiles("Book20.txt"); // + num
			break;
		case 3:
			df = new DataFiles("Book30.txt"); // + num
			break;
		default:
			break;
		}
		df.loadTheText();
		con = df.getContent();
		drawTheText(con);
		System.out.println(con);

		gc.drawRectangle(-1, -1, ((width / 20) + width - (width / 4))
				+ widthHelper, height - (height / 4));
		
		int rows = 1;
		for (String w : words) {
			gc.drawText(w, 10, rows);
			rows += 25;
		}

		final Text text = new Text(shell, SWT.BORDER);
		text.setBounds(width / 20, height - (height / 5), width - (width / 4),
				50);
		text.addKeyListener(new KeyListener() {
			@Override
			public void keyReleased(KeyEvent e) {
				if ((e.character == 32) || (e.character == 13)) {
					text.setText("");
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				if ((e.character == 32) || (e.character == 13)) {
					text.setText("");
				}
				if (e.character != 8) {
					letterCounter += 1;
				} else if (letterCounter > 0) {
					letterCounter -= 1;
				}
			}
		});
		final Button space = new Button(shell, SWT.PUSH);
		space.setText("Space");
		double width1 = ((width - ((width / 20) + (width - (width / 4)))) / 2) * 0.66;
		space.setBounds((width / 20) + (width - (width / 4)) + 50,
				(height - (height / 5)) - 50, (int) width1 * 2, 130);
		space.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				text.setText("");

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub

			}
		});
		text.setFont(new Font(d, "Arial", 25, SWT.NORMAL));
		text.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				if (text.getText().equals("true")) {
					Color green = d.getSystemColor(SWT.COLOR_GREEN);
					space.setBackground(green);
				} else {
					Color red = d.getSystemColor(SWT.COLOR_RED);
					space.setBackground(red);
				}

			}
		});

		font = new Font(d, "Arial", 40, SWT.NORMAL);
		gc.setFont(font);

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				gc.setForeground(shell.getDisplay().getSystemColor(
						SWT.COLOR_BLACK));
				gc.drawText(ch.getTillNow() + "  ", chWidthHelper
						- (ch.getTillNow().length() * 15), chHeightHelper);
				if (speed < 30) {
					gc.setForeground(shell.getDisplay().getSystemColor(
							SWT.COLOR_GREEN));
				} else if (speed > 65) {
					gc.setForeground(shell.getDisplay().getSystemColor(
							SWT.COLOR_RED));
				} else {
					gc.setForeground(shell.getDisplay().getSystemColor(
							SWT.COLOR_YELLOW));
				}
				speed = wpmCounter(letterCounter,
						Integer.parseInt(ch.getTillNow()));
				if (speed > 99) {
					gc.drawText(Integer.toString(speed) + " wpm  ",
							chWidthHelper - 100, wpmHeightHelper);
				} else {
					gc.drawText(Integer.toString(speed) + " wpm  ",
							chWidthHelper - 100, wpmHeightHelper);
				}
			}
		}
		d.dispose();
	}
}
