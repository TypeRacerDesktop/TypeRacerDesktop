package FrontEnd;

public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Window w = new Window();
		w.createCanvas();
	}

	
}
