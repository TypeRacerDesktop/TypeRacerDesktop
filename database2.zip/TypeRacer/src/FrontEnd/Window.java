package FrontEnd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import BackEnd.DataFiles;

//moje da se napravi nov
// class koito da ti
// otvarq tam menuto sas
// slojnostite i ot tam
// da ti vrashta imeto
// na faila koito trqbva
// da otvorish i veche
// da se zarejda nov
// class koito realno da
// ti pravi tam
// hronometar i celiq
// nov prozorec. Sled
// koeto shte ima da se
// otvarq nov class
// koito shte e lastest
// ranking results ili
// neshto takova.

public class Window {
	public Display d;
	public Shell shell;
	public Rectangle bds;
	private int width;
	private int height;
	public ArrayList<String> words = new ArrayList<String>();

	public Window() {
		d = new Display();
		shell = new Shell(d);

		bds = shell.getDisplay().getBounds();
		width = bds.width;
		height = bds.height;
	}

	public void createCanvas() {

		shell.setMaximized(true);

		final Button startGame = new Button(shell, SWT.PUSH);
		startGame.setText("Start Game");
		startGame
				.setBounds((width / 2) - 50, (height / 2) - 50 - 200, 100, 100);
		startGame.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				startGame();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button rankList = new Button(shell, SWT.PUSH);
		rankList.setText("Rank List");
		rankList.setBounds((width / 2) - 50, (height / 2) - 50 - 100, 100, 100);
		rankList.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				rankList();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button about = new Button(shell, SWT.PUSH);
		about.setText("About");
		about.setBounds((width / 2) - 50, (height / 2) - 50, 100, 100);
		about.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				about();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		shell.open();

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				d.sleep();
			}
		}
	}

	public void clearScreen(Shell shell) {
		for (Control kid : shell.getChildren()) {
			kid.dispose();
		}
	}

	public void startGame() {
		final Button easy = new Button(shell, SWT.PUSH);
		easy.setText("150");
		easy.setBounds((width / 2) - 50, (height / 2) - 50 - 200, 100, 100);
		easy.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				try {
					levelSelected(1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button medium = new Button(shell, SWT.PUSH);
		medium.setText("250");
		medium.setBounds((width / 2) - 50, (height / 2) - 50 - 100, 100, 100);
		medium.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				try {
					levelSelected(2);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		final Button hard = new Button(shell, SWT.PUSH);
		hard.setText("350");
		hard.setBounds((width / 2) - 50, (height / 2) - 50, 100, 100);
		hard.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				clearScreen(shell);
				try {
					levelSelected(3);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		shell.open();

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				d.sleep();
			}
		}
	}

	public void rankList() {

	}

	public void about() {

	}

	public void levelSelected(int i) throws IOException {
		Random rand = new Random();
		final Canvas canvas = new Canvas(shell, SWT.NO_BACKGROUND);
		switch (i) {
		case 1:
			int num = rand.nextInt(10); // tova shte e otdelen klas, funkciika
										// koqto shte ti vrashta direktno imeto
			DataFiles df = new DataFiles("Book1.txt");
			df.loadTheText();
			words = df.fromTextFileToWord(words);
			String con = df.getContent();
			GC gc = new GC(shell);
			
			
			gc.drawText(con, 1, 1);
			gc.dispose();
			final Text text = new Text(shell, SWT.BORDER);
			text.setBounds(width / 20, height - (height / 5), width
					- (width / 4), 50);
			text.addKeyListener(new KeyListener() {
				@Override
				public void keyReleased(KeyEvent e) {
					// TODO Auto-generated method stub
				}

				@Override
				public void keyPressed(KeyEvent e) {
					if (e.character == 32) {
						text.setText(text.getText() + "Some");
					}
				}
			});
			final Button space = new Button(shell, SWT.PUSH);
			space.setText("Space");
			double width1 = ((width - ((width / 20) + (width - (width / 4)))) / 2) * 0.66;
			space.setBounds((width / 20) + (width - (width / 4)) + 50,
					(height - (height / 5)) - 50, (int) width1 * 2, 130);

			text.addModifyListener(new ModifyListener() {
				@Override
				public void modifyText(ModifyEvent e) {
					if (text.getText().equals("true")) {
						Color green = d.getSystemColor(SWT.COLOR_GREEN);
						space.setBackground(green);
					} else {
						Color red = d.getSystemColor(SWT.COLOR_RED);
						space.setBackground(red);
					}

				}
			});
			break;
		case 2:

			break;
		case 3:

			break;
		default:
			break;
		}
	}
}
