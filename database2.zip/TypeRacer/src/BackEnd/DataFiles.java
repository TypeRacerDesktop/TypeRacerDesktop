package BackEnd;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DataFiles {
	private String name;
	private String content;

	public DataFiles(String name) {
		this.name = "D:\\eclipse\\TypeRacerDoc\\" + name;
		this.content = "";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String loadTheText() throws IOException {
		String line = null;

		@SuppressWarnings("resource")
		BufferedReader buffRdr = new BufferedReader(new FileReader(this.name));
		line = buffRdr.readLine();
		while (line != null) {
			this.content += line;
			line = buffRdr.readLine();
		}
		return this.content;
	}

	public ArrayList<String> fromTextFileToWord(ArrayList<String> words) {
		String helpForSplit[] = this.content.split(" ");
		for (String s : helpForSplit) {
			words.add(s);
		}
		return words;
	}
}
